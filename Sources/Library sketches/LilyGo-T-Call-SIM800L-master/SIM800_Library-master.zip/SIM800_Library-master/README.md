This code bin is changed based on [Seeeduino GPRS].
========================================
